# Packages and libraries
list.of.packages <- c("tidyverse",'zoo',"dplyr","readxl","ggplot2","fpp","fpp2","ggfortify", "portes","astsa","forecast")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages) 

library(readxl)
library(lubridate)
library(ggplot2)
library(ggfortify)
library(fpp2)
library(fpp)
library(forecast)
library(portes)
library(dplyr)
library(tidyverse)
library(zoo)

# Loading data
setwd("C:/Users/sdam/Documents/IESEG/Sem 2/Forecasting/Assignment") 
Turnover <- read_excel("DataSets2020_1.xlsx", sheet="Turnover")
Turnover_ts<-ts(Turnover[,2], frequency = 12, start = c(2000,1))

# Spliting the data in a training set up to December 2015 and a test set from January 2016 up to January 2020

ts_train <- window(Turnover_ts, end=c(2015,12))
ts_test <- window(Turnover_ts, start=c(2016,1))

######################################################################################################################################
# 1. Exploring data

#plotting the timeseries graphs

plot(Turnover_ts, main="Belgian beverages manufacturing industry - turnover index",
     xlab="Year", ylab="Turnover")
lines(ts_train, col="red")
lines(ts_test, col="blue")
legend("topleft", legend=c("Train", "Test"),col=c("red", "blue"), lty=1:1, cex=0.8, box.lty=0)


# plotting seasonality
ggseasonplot(Turnover_ts,year.labels=FALSE, continuous=TRUE, 
             main="Seasonal plot for Belgian beverages manufacturing industry - turnover index",
             xlab="Month", ylab="Turnover")

ggseasonplot(Turnover_ts, polar = TRUE,
             main="Seasonal plot for Belgian beverages manufacturing industry - turnover index",
             xlab="Month", ylab="Turnover")



#from the timeseries curve we can observe some seasonality and upward trend.

# adding year.labels=FALSE and continuous=TRUE  to confirm the upward trend.
ggseasonplot(Turnover_ts, polar = TRUE, year.labels=FALSE, continuous=TRUE, 
             main="Seasonal plot for Belgian beverages manufacturing industry - turnover index",
             xlab="Month", ylab="Turnover")

ggsubseriesplot(Turnover_ts, 
                main="Seasonal plot for Belgian beverages manufacturing industry - turnover index",
                xlab="Month", ylab="Turnover")



# plotting autocorrelation function ACF and partial autocorrelation function PACF 
ggAcf(Turnover_ts)
gglagplot(Turnover_ts)
tsdisplay(Turnover_ts)
acf(Turnover_ts, plot = FALSE)

####################################################################################################################
#2. Check whether transformation is required or not

BoxCox.lambda(Turnover_ts) #lambda value is 0.23

plot(BoxCox(Turnover_ts,lambda=0.23))

log_Turnover_ts   <- log(Turnover_ts)
plot(log_Turnover_ts,main="Belgium Turnover Index",ylab="TurnOver", xlab="Year")
tsdisplay(log_Turnover_ts)
tsdisplay(Turnover_ts)

adf.test(Turnover_ts)
adf.test(log_Turnover_ts)

#From the above tests it is shown that P value is less than 0.05 and hence NULL hypotheis
#can be rejected. Also it is non stationary and also PACF graph shows that r1 is large 
#and positive and hence we need to stabilize the variance using transformations which are required in
#ARIMA models

#Performing Seasonal differencing to stabilize the  series 

dif_log_Turnover_ts <- diff(log_Turnover_ts,12)
tsdisplay(dif_log_Turnover_ts)
#Performing Dickey-Fuller Test to test stationarity 
adf.test(dif_log_Turnover_ts)

#Now we split the transformed timeseries in to train and test 
train_log <- window(log_Turnover_ts, end=c(2015,12))	  
test_log <- window(log_Turnover_ts, start=c(2016,01))	

lines(train_log, col="red")
lines(test_log, col="blue")
h <- length(test_log)


#######################################################################################################################"
# 3. Create forecasts using the seasonal naive method. Check the residual diagnostics and the forecast accuracy.

# Model
snaive_forecast <- snaive(train_log)

# Chart with original and fitted data
autoplot(snaive_forecast, main="SNAIVE FORECAST",
         xlab="Year", ylab="Turnover") + autolayer(fitted(snaive_forecast))
# checking accuracy
accuracy<- accuracy(snaive_forecast,test_log)
accuracy
# checking summary of model
summary(snaive_forecast)
# checking residuals
checkresiduals(snaive_forecast)




##############################################################################################################################
# 4.	Use an STL decomposition to forecast the turnover index. Use the appropriate underlying methods to do so.
#     Check the residual diagnostics and the forecast accuracy.

STL_decomp <- stl(train_log[,1],
                  s.window="periodic", robust=TRUE,)
# Decomposition plot
autoplot(STL_decomp,main="Decomposition Belgian industry - turnover index")
# forecast
STL_forecast <- forecast(STL_decomp, method = "rwdrift", h=24)
plot(STL_forecast)
season_ajs<- seasadj(STL_decomp)
lines(season_ajs, col="red")
legend("topleft", legend="Season ajusted",col="red", lty=1:1, cex=0.8, box.lty=0)
# checking accuracy
accuracy<- accuracy(STL_forecast,test_log)
accuracy
# checking summary of model
summary(STL_forecast)
# checking residuals
checkresiduals(STL_forecast)



########################################################################################################################################
# 5.Generate forecasts using Holt-Winters' method. Check the residual diagnostics and the forecast accuracy

# Holts winter MODEL

#Turnover_train %>% BoxCox(lambda = opt_lambda)
hw_model_mult <- hw(train_log, damped=TRUE, seasonal="multiplicative")
hw_model_add <- hw(train_log, damped=TRUE, seasonal="additive")

# Chart with original and fitted data
autoplot(hw_model_mult, main="HW FORECAST MULTIPLICATIVE",
         xlab="Year", ylab="Turnover") + autolayer(fitted(hw_model_mult))

autoplot(hw_model_add, main="HW FORECAST ADDITIVE",
         xlab="Year", ylab="Turnover") + autolayer(fitted(hw_model_add))


# checking accuracy
accuracy_mult<- accuracy(hw_model_mult,test_log)
accuracy_mult
accuracy_add<- accuracy(hw_model_add,test_log)
accuracy_add


# checking summary of model
summary(hw_model_mult)
summary(hw_model_add)

# checking residuals
checkresiduals(hw_model_mult)
checkresiduals(hw_model_add)


###############################################################################################################################################"
# 6.	Generate forecasts using ETS. First, select the appropriate model(s) yourself and discuss their 
# performance. Compare these models with the results of the automated ETS procedure. Check the residual 
# diagnostics and the forecast accuracy for the various ETS models you've considered.



#Models without damping
mod1  <- ets(train_log, model="AAA")
mod2  <- ets(train_log, model="AAAd")
mod3  <- ets(train_log, model="MAA")
mod4  <- ets(train_log, model="MAAd")
mod5  <- ets(train_log, model="MAM")
mod6  <- ets(train_log, model="MMM")

# function for Models without damping
mod_undamp <- c("AAA", "AAAd", "MAA","MAAd", "MAM", "MMM")

result <- matrix(data=NA, nrow=6, ncol=5)
for (i in 1:6){
  model <- ets(train_log, model=mod_undamp[i],damped=FALSE)
  f <- forecast(model, h=24)
  a <- accuracy(f, test_log)
  result[i,1] <- model$aicc
  result[i,2] <- a[1,6]
  result[i,3] <- a[1,2]
  result[i,4] <- a[2,6]
  result[i,5] <- a[2,2]
}
rownames(result) <- mod_undamp
colnames(result) <- c("AICc", "MASE_train", "RMSE_train", "MASE_test", "RMSE_test")

result


# Models with damping
mod7  <- ets(train_log, model="AAA", damped=TRUE)
mod8  <- ets(train_log, model="AAAd", damped=TRUE)
mod9  <- ets(train_log, model="MAA", damped=TRUE)
mod10 <- ets(train_log, model="MAAd", damped=TRUE)
mod11 <- ets(train_log, model="MAM", damped=TRUE)
mod12 <- ets(train_log, model="MMM", damped=TRUE)

# function for Models with damping
mod_damp <- c("AAA_DUMPED","AAAd_DUMPED", "MAA_DUMPED","MAAd_DUMPED", "MAM_DUMPED", "MMM_DUMPED")

result2 <- matrix(data=NA, nrow=6, ncol=5)
for (i in 1:6){
  model <- ets(train_log, model=mod_damp[i],damped=TRUE)
  f <- forecast(model, h=24)
  a <- accuracy(f, test_log)
  result2[i,1] <- model$aicc
  result2[i,2] <- a[1,6]
  result2[i,3] <- a[1,2]
  result2[i,4] <- a[2,6]
  result2[i,5] <- a[2,2]
}
rownames(result2) <- mod_damp
colnames(result2) <- c("AICc", "MASE_train", "RMSE_train", "MASE_test", "RMSE_test")

result2

# combining the results from the models with and without damping
total<-rbind(result,result2)
total


#Since we check the mod6 gives the lowest RMSE and MASE on test, hence we choose this model to proceed with forecast
# checking accuracy
accuracy_ets<- accuracy(forecast(mod6),test_log)[,c(2,6)]
accuracy_ets
# checking summary of model
summary(mod6)
# checking residuals
checkresiduals(mod6)



# automated ETS procedure
auto_ets <- ets(train_log)
autoplot(forecast(auto_ets))
# checking accuracy
accuracy_ets<- accuracy(forecast(auto_ets),test_log)
accuracy_ets
# checking summary of model
summary(auto_ets)
# checking residuals
checkresiduals(auto_ets)


#######################################################################################################################################
#Question 7: ARIMA models
#Pre-reqisite of Arima Models is, it should be stationary
#We will be using the timeseries from the above where we have accounted for lag 

dif_log_Turnover_ts 
plot(dif_log_Turnover_ts)
tsdisplay(dif_log_Turnover_ts)
#We will be performing Seasonal Arima modeling
#From  we can see that in ACF there is a spike at lag 12 
#whereas in PACF decay in the seasonal lags (12,24,36)

#We start with the below analysis of Arima models manually

#Starting with the Seasonal Part

#So, we can see that there are 2 spikes in lags IN PACF so P=2,d=0
#Q=1or 2 or 3 as there is only one spike outside ACF signifcantly
#we will try all the above values in the model

#Non Seasonal Part
#Assuming p=1 as we can clearly see from ACF, one significant spike,d=0
#q=can be 1,2,3 

#Lets start with the test

# 
Train_Arima <- window(dif_log_Turnover_ts, end=c(2015,12))	  
Test_Arima <- window(dif_log_Turnover_ts, start=c(2016,01))
tsdisplay(Train_Arima)

Arima_fit1 <- Arima(Train_Arima, order=c(1,0,1), seasonal=c(2,0,2))
Arima_fit2 <- Arima(Train_Arima, order=c(2,0,1), seasonal=c(1,0,2))
Arima_fit3 <- Arima(Train_Arima, order=c(1,0,2), seasonal=c(2,0,2))
Arima_fit4 <-  Arima(Train_Arima, order=c(1,0,1), seasonal=c(2,0,1))

summary(Arima_fit1)#AIC=-506
summary(Arima_fit2)#AIC=-498.26
summary(Arima_fit3)#AIC=-508.33
summary(Arima_fit4)#AIC=-498.92 

#Considering All the above ouputs the best seems to be the model 3 with 
#low AIC from all

fcast_Arima1 <- forecast(Arima_fit1, h=24)
fcast_Arima2 <- forecast(Arima_fit2, h=24)
fcast_Arima3 <- forecast(Arima_fit3, h=24)
fcast_Arima4 <- forecast(Arima_fit4, h=24)

accuracy(fcast_Arima1,Test_Arima)
accuracy(fcast_Arima2,Test_Arima)
accuracy(fcast_Arima3,Test_Arima)
accuracy(fcast_Arima4,Test_Arima)

#Lets see the automatic model picked by the system
auto_arima <-auto.arima(Train_Arima)
#The model chosen is ARIMA(1,0,1)(2,0,2)[12] with non-zero mean which is not same
#from what we chose  in the manual analysis
#since the manuall ARIMA model has less AIC then the automatic model, we pick the manual one (1,0,2)(2,0,2)[12]


Arima_fit3_res <- residuals(Arima_fit3)
tsdisplay(Arima_fit3_res)

#Even though p value is small, but still from the residuals graphs it can been information is still left
adf.test(Arima_fit3_res)  






#*************************************The best Model******************************************

#Snaive has RSME= 0.145 IN TEST and  MAE= 0.128
#STL has RSME= 0.085  IN TEST and  MAE= 0.0729
#Holt mult has RSME= 0.120 IN TEST and  MAE= 0.106
#Holt add has RSME= 0.124 IN TEST and  MAE= 0.110
#ETS manual has RSME= 0.083 IN TEST and  MAE= 1.081
#ETS auto has RSME= 0.084  IN TEST and  MAE= 0.072
#Arima has RSME= 0.077 IN TEST and  MAE= 0.065

#Considering RSME for all the above test, the best comes out to ARIMA



################################################################################################################################################################################



# 9. Generate out of sample forecasts up to December 2020, based on the complete time series. 
#    Discuss your results.

# automated ARIMA procedure
out_of_sample_forecast<- forecast(Arima_fit3, h = 24)

# Chart with original and fitted data
autoplot(out_of_sample_forecast, main="Manual ARIMA3 FORECAST (1,0,2)(2,0,2)[12] with drift",
         xlab="Year", ylab="Turnover") + autolayer(fitted(auto_arima))

# checking summary of model
summary(out_of_sample_forecast)

# checking residuals
checkresiduals(out_of_sample_forecast)








# 10. In addition, generate the seasonally adjusted time series for the Turnover data. Estimate an 
#     (auto-) ARIMA model and an (auto-)ETS model for this non-seasonal time series. Compare the forecast 
#     accuracy and residual diagnostics of both models, and select the final model for the seasonally adjusted 
#     series. Generate out of sample forecasts up to December 2020, based on the complete time series. 
#     Discuss your results.


# generating seasonally adjusted time series
pre_data<- decompose(Turnover_ts, type="multiplicative")
seasonally_adjusted <- seasadj(pre_data)

plot(Turnover_ts, col="grey",
     main="Belgian beverages manufacturing industry - turnover index",
     xlab="Year", ylab="Turnover")
lines(seasonally_adjusted,col="red",
      ylab="Seasonally adjusted")
legend("topleft", legend="seasonally adjusted",col="red", lty=1:1, cex=0.8, box.lty=0)

# Dickey-Fuller test
adf.test(seasonally_adjusted, alternative = "stationary")

# automated ARIMA procedure
auto_arima <- auto.arima(seasonally_adjusted)
tsdisplay(residuals(auto_arima))
auto_arima_forecast<- forecast(auto.arima(seasonally_adjusted), h = 11)
# Chart with original and fitted data
autoplot(auto_arima_forecast, main="AUTO ARIMA FORECAST (5,1,3) with drift",
         xlab="Year", ylab="Turnover") + autolayer(fitted(auto_arima))

# checking summary of model
summary(auto_arima)
# checking residuals
checkresiduals(auto_arima)



# automated ETS procedure
auto_ets <- ets(seasonally_adjusted)
tsdisplay(residuals(auto_ets))
auto_ETS_forecast<- (forecast(auto_ets, h=11))
# Chart with original and fitted data
autoplot(auto_ETS_forecast, main="AUTO ETS FORECAST (M,A,N)",
         xlab="Year", ylab="Turnover") + autolayer(fitted(auto_ets))
# checking summary of model
summary(auto_ets)
# checking residuals
checkresiduals(auto_ets)




###########################################################################################################
#######---------------------------Exercise 2 ---------------------------------########################
#############################################################################################################

#The dataset used is a superstore dataset that tracks sales of different products from January 2014 to December 2017
#First we manipulate the dataframe to get data organized as sum of sales for each Month in a year

df <-  read_excel("GlobalSuperstore.xlsx", sheet="Orders")
df_furn <- as.data.frame(filter(df, Category == "Furniture"))
min(df_furn$`Order Date`)
max(df_furn$`Order Date`)
df_final <- select(df_furn,`Order Date`,Sales)

df_final <- df_final %>% group_by(Year=year(`Order Date`),Month =month(`Order Date`)) %>% summarise(Sales = sum(Sales))
df_final <- within(df_final, Date <- sprintf("%d-%02d", Year, Month))
df_final <- select(df_final,Date,Sales)

df_final$Year <- NULL

#Now we convert the data frame to timeseries
df_ts<-ts(df_final[,2], frequency = 12, start = c(2014,1))

#Divide the timeseries into train (Till Dec 2016)and test(from Jan 2017 to Dec 2017) 
ts_train <- window(df_ts, end=c(2016,12))
ts_test <- window(df_ts, start=c(2017,1))

#Explotaory data Analysis
plot(df_ts, main="Furniture Sales of Superstore",
     xlab="Year", ylab="Sales")
lines(ts_train, col="red")
lines(ts_test, col="blue")
legend("topleft", legend=c("Train", "Test"),col=c("red", "blue"), lty=1:1, cex=0.8, box.lty=0)

#we can observe some seasonality but there is no trend. We plot some further graphs to confirm the same
#plotting seasonality
ggseasonplot(df_ts,year.labels=FALSE, continuous=TRUE, 
             main="Furniture Sales of Superstore",
             xlab="Month", ylab="Sales")

ggseasonplot(df_ts, polar = TRUE,
             main="Furniture Sales of Superstore",
             xlab="Month", ylab="Sales")

# adding year.labels=FALSE and continuous=TRUE allowed me to confirm the trend.
ggseasonplot(df_ts, polar = TRUE, year.labels=FALSE, continuous=TRUE, 
             main="Furniture Sales of Superstore",
             xlab="Month", ylab="Sales")

ggsubseriesplot(df_ts, 
                main="Furniture Sales of Superstore",
                xlab="Month", ylab="Sales")

# plotting correlations associated with the lag ACF (autocorrelation function) and PACF (partial autocorrelation function)
ggAcf(df_ts)
gglagplot(df_ts)
tsdisplay(df_ts)
acf(df_ts, plot = FALSE)


#Lets check whether transformation is required or not

BoxCox.lambda(df_ts) #lambda value is 0.4023197

plot(BoxCox(df_ts,lambda=0.4023197))

#based on value of lambda we go for cube transformation of the timeseries 

cube_df_ts <- sign(df_ts) * abs(df_ts)^(1/3)
plot(cube_df_ts,main="Superstore Furniture  Sales Index",ylab="Sales", xlab="Year")
tsdisplay(cube_df_ts)
tsdisplay(df_ts)

adf.test(df_ts)
adf.test(cube_df_ts)


train_cube <- window(cube_df_ts, end=c(2016,12))	  
test_cube <- window(cube_df_ts, start=c(2017,01))	


plot(cube_df_ts,main="Superstore Furniture  Sales Index",ylab="Sales", xlab="Year")
lines(train_cube, col="red")
lines(test_cube, col="blue")
h <- length(test_log)


#Applying STL

STL_decomp <- stl(train_cube[,1],
                  s.window="periodic", robust=TRUE,)
# Decomposition plot
autoplot(STL_decomp,main="Decomposition Superstore Furniture Sales index")
# forecast
STL_forecast <- forecast(STL_decomp, method = "rwdrift", h=24)
plot(STL_forecast)
season_ajs<- seasadj(STL_decomp)
lines(season_ajs, col="red")
legend("topleft", legend="Season ajusted",col="red", lty=1:1, cex=0.8, box.lty=0)
# checking accuracy
accuracy<- accuracy(STL_forecast,test_cube)
accuracy
# checking summary of model
summary(STL_forecast)
# checking residuals
checkresiduals(STL_forecast)


# Holts winter MODEL

#Sales_train %>% BoxCox(lambda = opt_lambda)
hw_model_mult <- hw(train_cube, damped=TRUE, seasonal="multiplicative")
hw_model_add <- hw(train_cube, damped=TRUE, seasonal="additive")

# Chart with original and fitted data
autoplot(hw_model_mult, main="HW FORECAST MULTIPLICATIVE",
         xlab="Year", ylab="Sales") + autolayer(fitted(hw_model_mult))

autoplot(hw_model_add, main="HW FORECAST ADDITIVE",
         xlab="Year", ylab="Sales") + autolayer(fitted(hw_model_add))


# checking accuracy
accuracy_mult<- accuracy(hw_model_mult,test_cube)
accuracy_mult
accuracy_add<- accuracy(hw_model_add,test_cube)
accuracy_add


# checking summary of model
summary(hw_model_mult)
summary(hw_model_add)

# checking residuals
checkresiduals(hw_model_mult)
checkresiduals(hw_model_add)




#
#STL has RSME= 3.660  IN TEST and  MAE= 3.372
#Holt mult has RSME= 2.265 IN TEST and  MAE= 2.036
#Holt add has RSME= 2.737 IN TEST and  MAE= 2.446
#
#
#
